﻿-----------------------------------------------------
-- Export file for user T073                       --
-- Created by n000074170 on 2018/5/28, 下午 04:22:46 --
-----------------------------------------------------

spool objects.log

prompt
prompt Creating table T0NKDG04
prompt =======================
prompt
create table T0NKDG04
(
  OPCO    VARCHAR2(2) not null,
  OPPLD   VARCHAR2(2) not null,
  OPDP    VARCHAR2(4) not null,
  CTLPTID VARCHAR2(15) not null,
  CTLPTNM VARCHAR2(60),
  RFID    VARCHAR2(20),
  XREM    VARCHAR2(75),
  TXCO    VARCHAR2(2),
  TXEMP   VARCHAR2(10),
  TXMCH   VARCHAR2(30),
  TXTM    VARCHAR2(16),
  AREID   VARCHAR2(10)
)
;
alter table T0NKDG04
  add constraint PK_T0NKDG04 primary key (OPCO, OPPLD, OPDP, CTLPTID);

prompt
prompt Creating table T0NKDG09
prompt =======================
prompt
create table T0NKDG09
(
  OPCO  VARCHAR2(2) not null,
  OPPLD VARCHAR2(2) not null,
  OPDP  VARCHAR2(4) not null,
  WAYID VARCHAR2(8) not null,
  URID  VARCHAR2(10) not null,
  TXCO  VARCHAR2(2),
  TXEMP VARCHAR2(10),
  TXMCH VARCHAR2(30),
  TXTM  VARCHAR2(16)
)
;
alter table T0NKDG09
  add constraint PK_T0NKDG09 primary key (OPCO, OPPLD, OPDP, WAYID, URID);

prompt
prompt Creating table T0NKDG0A
prompt =======================
prompt
create table T0NKDG0A
(
  DTID  VARCHAR2(1) not null,
  ID    VARCHAR2(3) not null,
  NM    VARCHAR2(180),
  TXDAT VARCHAR2(7)
)
;
comment on table T0NKDG0A
  is '各項代號檔';
comment on column T0NKDG0A.DTID
  is '資料別';
comment on column T0NKDG0A.ID
  is '代號';
comment on column T0NKDG0A.NM
  is '名稱';
comment on column T0NKDG0A.TXDAT
  is '異動日期';
alter table T0NKDG0A
  add constraint PK_T0NKDG0A primary key (DTID, ID);

prompt
prompt Creating table T0NKDG0B
prompt =======================
prompt
create table T0NKDG0B
(
  CO      VARCHAR2(2),
  PMFCT   VARCHAR2(3),
  PMSECT  VARCHAR2(4),
  MNTCO   VARCHAR2(2),
  MNTFCT  VARCHAR2(4),
  MNTSECT VARCHAR2(4),
  TXTM    VARCHAR2(16)
)
;
comment on table T0NKDG0B
  is '生產及保養部門檔';
comment on column T0NKDG0B.CO
  is '公司';
comment on column T0NKDG0B.PMFCT
  is '生產廠';
comment on column T0NKDG0B.PMSECT
  is '生產課';
comment on column T0NKDG0B.MNTCO
  is '保養公司';
comment on column T0NKDG0B.MNTFCT
  is '保養廠';
comment on column T0NKDG0B.MNTSECT
  is '保養課';
comment on column T0NKDG0B.TXTM
  is '異動時間';

prompt
prompt Creating table T0NKDGM2
prompt =======================
prompt
create table T0NKDGM2
(
  OPCO   VARCHAR2(2) not null,
  OPPLD  VARCHAR2(2) not null,
  OPDP   VARCHAR2(4) not null,
  FUN    VARCHAR2(1) not null,
  CHKKD  VARCHAR2(2) not null,
  CYCQTY NUMBER(3) not null,
  CYCUN  VARCHAR2(1) not null,
  EQKD   VARCHAR2(4) not null,
  EQTY   VARCHAR2(3) not null,
  CO     VARCHAR2(2) not null,
  PMFCT  VARCHAR2(2) not null,
  TXCO   VARCHAR2(2),
  TXEMP  VARCHAR2(10),
  TXMCH  VARCHAR2(30),
  TXTM   VARCHAR2(16)
)
;
comment on table T0NKDGM2
  is '檢查基準建檔';
comment on column T0NKDGM2.OPCO
  is '作業公司';
comment on column T0NKDGM2.OPPLD
  is '作業廠處';
comment on column T0NKDGM2.OPDP
  is '作業部門';
comment on column T0NKDGM2.FUN
  is '機能';
comment on column T0NKDGM2.CHKKD
  is '檢查類別';
comment on column T0NKDGM2.CYCQTY
  is '週期數量';
comment on column T0NKDGM2.CYCUN
  is '週期單位';
comment on column T0NKDGM2.EQKD
  is '設備類別';
comment on column T0NKDGM2.EQTY
  is '設備型式';
comment on column T0NKDGM2.CO
  is '公司';
comment on column T0NKDGM2.PMFCT
  is '生產廠';
comment on column T0NKDGM2.TXCO
  is '異動公司';
comment on column T0NKDGM2.TXEMP
  is '異動人員';
comment on column T0NKDGM2.TXMCH
  is '異動機台';
comment on column T0NKDGM2.TXTM
  is '異動時間';
alter table T0NKDGM2
  add constraint PK_T0NKDGM2 primary key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT);

prompt
prompt Creating table T0NKDGD2_1
prompt =========================
prompt
create table T0NKDGD2_1
(
  OPCO   VARCHAR2(2) not null,
  OPPLD  VARCHAR2(2) not null,
  OPDP   VARCHAR2(4) not null,
  FUN    VARCHAR2(1) not null,
  CHKKD  VARCHAR2(2) not null,
  CYCQTY NUMBER(3),
  CYCUN  VARCHAR2(1),
  EQKD   VARCHAR2(4) not null,
  EQTY   VARCHAR2(3) not null,
  CO     VARCHAR2(2) not null,
  PMFCT  VARCHAR2(2) not null,
  EQNO   VARCHAR2(60) not null,
  MPZ    VARCHAR2(10),
  MPSYS  VARCHAR2(6),
  TXCO   VARCHAR2(2),
  TXEMP  VARCHAR2(10),
  TXMCH  VARCHAR2(30),
  TXTM   VARCHAR2(16)
)
;
comment on table T0NKDGD2_1
  is '檢查基準建檔';
comment on column T0NKDGD2_1.OPCO
  is '作業公司';
comment on column T0NKDGD2_1.OPPLD
  is '作業廠處';
comment on column T0NKDGD2_1.OPDP
  is '作業部門';
comment on column T0NKDGD2_1.FUN
  is '機能';
comment on column T0NKDGD2_1.CHKKD
  is '檢查類別';
comment on column T0NKDGD2_1.CYCQTY
  is '週期數量';
comment on column T0NKDGD2_1.CYCUN
  is '週期單位';
comment on column T0NKDGD2_1.EQKD
  is '設備類別';
comment on column T0NKDGD2_1.EQTY
  is '設備型式';
comment on column T0NKDGD2_1.CO
  is '公司';
comment on column T0NKDGD2_1.PMFCT
  is '生產廠';
comment on column T0NKDGD2_1.EQNO
  is '設備編號';
comment on column T0NKDGD2_1.MPZ
  is '製程區';
comment on column T0NKDGD2_1.MPSYS
  is '製程系統';
comment on column T0NKDGD2_1.TXCO
  is '異動公司';
comment on column T0NKDGD2_1.TXEMP
  is '異動人員';
comment on column T0NKDGD2_1.TXMCH
  is '異動機台';
comment on column T0NKDGD2_1.TXTM
  is '異動時間';
alter table T0NKDGD2_1
  add constraint PK_T0NKDGD2_1 primary key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO);
alter table T0NKDGD2_1
  add constraint FK_T0NKDGD2_1 foreign key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT)
  references T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT) on delete cascade;

prompt
prompt Creating table T0NKDGD2_2
prompt =========================
prompt
create table T0NKDGD2_2
(
  OPCO  VARCHAR2(2) not null,
  OPPLD VARCHAR2(2) not null,
  OPDP  VARCHAR2(4) not null,
  FUN   VARCHAR2(1) not null,
  CHKKD VARCHAR2(2) not null,
  EQKD  VARCHAR2(4) not null,
  EQTY  VARCHAR2(3) not null,
  CO    VARCHAR2(2) not null,
  PMFCT VARCHAR2(2) not null,
  EQNO  VARCHAR2(60) not null,
  CHKIT VARCHAR2(3) not null,
  ITNM  VARCHAR2(90),
  TXCO  VARCHAR2(2),
  TXEMP VARCHAR2(10),
  TXMCH VARCHAR2(30),
  TXTM  VARCHAR2(16)
)
;
comment on table T0NKDGD2_2
  is '檢查基準建檔';
comment on column T0NKDGD2_2.OPCO
  is '作業公司';
comment on column T0NKDGD2_2.OPPLD
  is '作業廠處';
comment on column T0NKDGD2_2.OPDP
  is '作業部門';
comment on column T0NKDGD2_2.FUN
  is '機能';
comment on column T0NKDGD2_2.CHKKD
  is '檢查類別';
comment on column T0NKDGD2_2.EQKD
  is '設備類別';
comment on column T0NKDGD2_2.EQTY
  is '設備型式';
comment on column T0NKDGD2_2.CO
  is '公司';
comment on column T0NKDGD2_2.PMFCT
  is '生產廠';
comment on column T0NKDGD2_2.EQNO
  is '設備編號';
comment on column T0NKDGD2_2.CHKIT
  is '檢查項目';
comment on column T0NKDGD2_2.ITNM
  is '項目名稱';
comment on column T0NKDGD2_2.TXCO
  is '異動公司';
comment on column T0NKDGD2_2.TXEMP
  is '異動人員';
comment on column T0NKDGD2_2.TXMCH
  is '異動機台';
comment on column T0NKDGD2_2.TXTM
  is '異動時間';
alter table T0NKDGD2_2
  add constraint PK_T0NKDGD2_2 primary key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO, CHKIT);
alter table T0NKDGD2_2
  add constraint FK_T0NKDGD2_2 foreign key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO)
  references T0NKDGD2_1 (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO) on delete cascade;

prompt
prompt Creating table T0NKDGD2_3
prompt =========================
prompt
create table T0NKDGD2_3
(
  OPCO     VARCHAR2(2) not null,
  OPPLD    VARCHAR2(2) not null,
  OPDP     VARCHAR2(4) not null,
  FUN      VARCHAR2(1) not null,
  CHKKD    VARCHAR2(2) not null,
  EQKD     VARCHAR2(4) not null,
  EQTY     VARCHAR2(3) not null,
  CO       VARCHAR2(2) not null,
  PMFCT    VARCHAR2(2) not null,
  EQNO     VARCHAR2(60) not null,
  CHKIT    VARCHAR2(3) not null,
  ITNM     VARCHAR2(90),
  STDID    VARCHAR2(3) not null,
  STDNM    VARCHAR2(300),
  UN       VARCHAR2(15),
  UPL      NUMBER(8,2),
  LL       NUMBER(8,2),
  JUDGEITR VARCHAR2(1),
  SLBD     VARCHAR2(2),
  TXCO     VARCHAR2(2),
  TXEMP    VARCHAR2(10),
  TXMCH    VARCHAR2(30),
  TXTM     VARCHAR2(16)
)
;
comment on table T0NKDGD2_3
  is '檢查基準建檔';
comment on column T0NKDGD2_3.OPCO
  is '作業公司';
comment on column T0NKDGD2_3.OPPLD
  is '作業廠處';
comment on column T0NKDGD2_3.OPDP
  is '作業部門';
comment on column T0NKDGD2_3.FUN
  is '機能';
comment on column T0NKDGD2_3.CHKKD
  is '檢查類別';
comment on column T0NKDGD2_3.EQKD
  is '設備類別';
comment on column T0NKDGD2_3.EQTY
  is '設備型式';
comment on column T0NKDGD2_3.CO
  is '公司';
comment on column T0NKDGD2_3.PMFCT
  is '生產廠';
comment on column T0NKDGD2_3.EQNO
  is '設備編號';
comment on column T0NKDGD2_3.CHKIT
  is '檢查項目';
comment on column T0NKDGD2_3.ITNM
  is '項目名稱';
comment on column T0NKDGD2_3.STDID
  is '基準代號';
comment on column T0NKDGD2_3.STDNM
  is '基準名稱';
comment on column T0NKDGD2_3.UN
  is '單位';
comment on column T0NKDGD2_3.UPL
  is '上限';
comment on column T0NKDGD2_3.LL
  is '下限';
comment on column T0NKDGD2_3.JUDGEITR
  is '判斷';
comment on column T0NKDGD2_3.SLBD
  is '自建';
comment on column T0NKDGD2_3.TXCO
  is '異動公司';
comment on column T0NKDGD2_3.TXEMP
  is '異動人員';
comment on column T0NKDGD2_3.TXMCH
  is '異動機台';
comment on column T0NKDGD2_3.TXTM
  is '異動時間';
alter table T0NKDGD2_3
  add constraint PK_T0NKDGD2_3 primary key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO, CHKIT, STDID);
alter table T0NKDGD2_3
  add constraint FK1_T0NKDGD2_3 foreign key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO)
  references T0NKDGD2_1 (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO);
alter table T0NKDGD2_3
  add constraint FK_T0NKDGD2_3 foreign key (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO, CHKIT)
  references T0NKDGD2_2 (OPCO, OPPLD, OPDP, FUN, CHKKD, EQKD, EQTY, CO, PMFCT, EQNO, CHKIT) on delete cascade;

prompt
prompt Creating table T0NKDGM5
prompt =======================
prompt
create table T0NKDGM5
(
  OPCO      VARCHAR2(2) not null,
  OPPLD     VARCHAR2(2) not null,
  OPDP      VARCHAR2(4) not null,
  WAYID     VARCHAR2(8) not null,
  WAYNM     VARCHAR2(120),
  FUN       VARCHAR2(1),
  CYCQTY    NUMBER(3),
  CYCUN     VARCHAR2(2),
  PAUBEGDAT VARCHAR2(7),
  PAUPAUDAT VARCHAR2(7),
  DDUHOL    VARCHAR2(1),
  LSTCHKDAT VARCHAR2(7),
  NXTCHKDAT VARCHAR2(7),
  APSTS     VARCHAR2(1),
  FOLCNT    NUMBER(2),
  NTITM     VARCHAR2(16),
  ABMK      VARCHAR2(1),
  TXCO      VARCHAR2(2),
  TXEMP     VARCHAR2(10),
  TXMCH     VARCHAR2(30),
  TXTM      VARCHAR2(16)
)
;
comment on table T0NKDGM5
  is '巡檢路線建檔(主檔)';
comment on column T0NKDGM5.OPCO
  is '作業公司';
comment on column T0NKDGM5.OPPLD
  is '作業廠處';
comment on column T0NKDGM5.OPDP
  is '作業部門';
comment on column T0NKDGM5.WAYID
  is '路線代號';
comment on column T0NKDGM5.WAYNM
  is '路線名稱';
comment on column T0NKDGM5.FUN
  is '機能';
comment on column T0NKDGM5.CYCQTY
  is '週期數量';
comment on column T0NKDGM5.CYCUN
  is '週期單位';
comment on column T0NKDGM5.PAUBEGDAT
  is '暫停開始日';
comment on column T0NKDGM5.PAUPAUDAT
  is '暫停停止日';
comment on column T0NKDGM5.DDUHOL
  is '扣除假日';
comment on column T0NKDGM5.LSTCHKDAT
  is '上次檢查日';
comment on column T0NKDGM5.NXTCHKDAT
  is '下次檢查日';
comment on column T0NKDGM5.APSTS
  is '核簽狀態';
comment on column T0NKDGM5.FOLCNT
  is '跟催次數';
comment on column T0NKDGM5.NTITM
  is '通知時間';
comment on column T0NKDGM5.ABMK
  is '異常註記';
comment on column T0NKDGM5.TXCO
  is '異動公司';
comment on column T0NKDGM5.TXEMP
  is '異動人員';
comment on column T0NKDGM5.TXMCH
  is '異動機台';
comment on column T0NKDGM5.TXTM
  is '異動時間';
alter table T0NKDGM5
  add constraint PK_T0NKDGM5 primary key (OPCO, OPPLD, OPDP, WAYID);

prompt
prompt Creating table T0NKDGD5_1
prompt =========================
prompt
create table T0NKDGD5_1
(
  OPCO    VARCHAR2(2) not null,
  OPPLD   VARCHAR2(2) not null,
  OPDP    VARCHAR2(4) not null,
  WAYID   VARCHAR2(8) not null,
  SQNO    VARCHAR2(4) not null,
  CTLPTID VARCHAR2(15),
  TXCO    VARCHAR2(2),
  TXEMP   VARCHAR2(10),
  TXMCH   VARCHAR2(30),
  TXTM    VARCHAR2(16),
  GROUPMK VARCHAR2(1),
  PATRTM  NUMBER(6)
)
;
comment on table T0NKDGD5_1
  is '巡檢路線建檔(主檔)';
comment on column T0NKDGD5_1.OPCO
  is '作業公司';
comment on column T0NKDGD5_1.OPPLD
  is '作業廠處';
comment on column T0NKDGD5_1.OPDP
  is '作業部門';
comment on column T0NKDGD5_1.WAYID
  is '路線代號';
comment on column T0NKDGD5_1.SQNO
  is '序號';
comment on column T0NKDGD5_1.CTLPTID
  is '管制點代號';
comment on column T0NKDGD5_1.TXCO
  is '異動公司';
comment on column T0NKDGD5_1.TXEMP
  is '異動人員';
comment on column T0NKDGD5_1.TXMCH
  is '異動機台';
comment on column T0NKDGD5_1.TXTM
  is '異動時間';
comment on column T0NKDGD5_1.GROUPMK
  is '群組註記';
comment on column T0NKDGD5_1.PATRTM
  is '巡查時間';
alter table T0NKDGD5_1
  add constraint PK_T0NKDGD5_1 primary key (OPCO, OPPLD, OPDP, WAYID, SQNO);
alter table T0NKDGD5_1
  add constraint FK1_T0NKDGD5_1 foreign key (OPCO, OPPLD, OPDP, CTLPTID)
  references T0NKDG04 (OPCO, OPPLD, OPDP, CTLPTID) on delete set null
  deferrable initially deferred;
alter table T0NKDGD5_1
  add constraint FK_T0NKDGD5_1 foreign key (OPCO, OPPLD, OPDP, WAYID)
  references T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID) on delete cascade;

prompt
prompt Creating table T0NKDGD5_2
prompt =========================
prompt
create table T0NKDGD5_2
(
  OPCO   VARCHAR2(2) not null,
  OPPLD  VARCHAR2(2) not null,
  OPDP   VARCHAR2(4) not null,
  WAYID  VARCHAR2(8) not null,
  SQNO   VARCHAR2(4) not null,
  IT     VARCHAR2(3) not null,
  CO     VARCHAR2(2),
  PMFCT  VARCHAR2(2),
  MPZ    VARCHAR2(10),
  MPSYS  VARCHAR2(6),
  EQNO   VARCHAR2(60),
  EQNM   VARCHAR2(90),
  CHKKD1 VARCHAR2(2),
  CHKKD2 VARCHAR2(2),
  CHKKD3 VARCHAR2(2),
  TXCO   VARCHAR2(2),
  TXEMP  VARCHAR2(10),
  TXMCH  VARCHAR2(30),
  TXTM   VARCHAR2(16),
  PATRTM NUMBER(6),
  CYCQTY NUMBER(3),
  CYCUN  VARCHAR2(2)
)
;
comment on table T0NKDGD5_2
  is '巡檢路線建檔(明細)';
comment on column T0NKDGD5_2.OPCO
  is '作業公司';
comment on column T0NKDGD5_2.OPPLD
  is '作業廠處';
comment on column T0NKDGD5_2.OPDP
  is '作業部門';
comment on column T0NKDGD5_2.WAYID
  is '路線代號';
comment on column T0NKDGD5_2.SQNO
  is '序號';
comment on column T0NKDGD5_2.IT
  is '項次';
comment on column T0NKDGD5_2.CO
  is '公司';
comment on column T0NKDGD5_2.PMFCT
  is '生產廠';
comment on column T0NKDGD5_2.MPZ
  is '製程區';
comment on column T0NKDGD5_2.MPSYS
  is '製程系統';
comment on column T0NKDGD5_2.EQNO
  is '設備編號';
comment on column T0NKDGD5_2.EQNM
  is '設備名稱';
comment on column T0NKDGD5_2.CHKKD1
  is '檢查類別1';
comment on column T0NKDGD5_2.CHKKD2
  is '檢查類別2';
comment on column T0NKDGD5_2.CHKKD3
  is '檢查類別3';
comment on column T0NKDGD5_2.TXCO
  is '異動公司';
comment on column T0NKDGD5_2.TXEMP
  is '異動人員';
comment on column T0NKDGD5_2.TXMCH
  is '異動機台';
comment on column T0NKDGD5_2.TXTM
  is '異動時間';
comment on column T0NKDGD5_2.PATRTM
  is '巡查時間';
comment on column T0NKDGD5_2.CYCQTY
  is '周期數量';
comment on column T0NKDGD5_2.CYCUN
  is '周期單位';
alter table T0NKDGD5_2
  add constraint PK_T0NKDGD5_2 primary key (OPCO, OPPLD, OPDP, WAYID, SQNO, IT);
alter table T0NKDGD5_2
  add constraint FK1_T0NKDGD5_2 foreign key (OPCO, OPPLD, OPDP, WAYID, SQNO)
  references T0NKDGD5_1 (OPCO, OPPLD, OPDP, WAYID, SQNO) on delete cascade;
alter table T0NKDGD5_2
  add constraint FK2_T0NKDGD5_2 foreign key (OPCO, OPPLD, OPDP, WAYID)
  references T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID) on delete cascade;
create index I1_T0NKDGD5_2 on T0NKDGD5_2 (OPCO, OPPLD, OPDP, CO, PMFCT, EQNO);

prompt
prompt Creating table T0NKPME0
prompt =======================
prompt
create table T0NKPME0
(
  CO     VARCHAR2(2) not null,
  PMFCT  VARCHAR2(4) not null,
  MPZID  VARCHAR2(10) not null,
  CNM    VARCHAR2(60),
  ENM    VARCHAR2(40),
  CSTCEN VARCHAR2(4),
  TXDAT  VARCHAR2(16),
  TXEMP  VARCHAR2(10),
  TXCO   VARCHAR2(2),
  TXMCH  VARCHAR2(30)
)
;

prompt
prompt Creating table T0NKPME1
prompt =======================
prompt
create table T0NKPME1
(
  CO      VARCHAR2(2) not null,
  PMFCT   VARCHAR2(4) not null,
  MPZID   VARCHAR2(10) not null,
  MPSYSID VARCHAR2(9) not null,
  CNM     VARCHAR2(60),
  ENM     VARCHAR2(80),
  TXDAT   VARCHAR2(16),
  TXEMP   VARCHAR2(10),
  TXCO    VARCHAR2(2),
  TXMCH   VARCHAR2(30)
)
;

prompt
prompt Creating table T0NKPME3
prompt =======================
prompt
create table T0NKPME3
(
  CO         VARCHAR2(2) not null,
  PMFCT      VARCHAR2(4) not null,
  EQNO       VARCHAR2(40) not null,
  EQNM       VARCHAR2(90),
  EQKD       VARCHAR2(4),
  ASTNO      VARCHAR2(12),
  MEPHMAT    VARCHAR2(20),
  MPZ        VARCHAR2(10),
  MPSYS      VARCHAR2(9),
  EQTY       VARCHAR2(3),
  IMPTSAFSYS VARCHAR2(1),
  IMPTDGGD   VARCHAR2(1),
  RBIMK      VARCHAR2(1),
  SRPMK      VARCHAR2(1),
  SRPRS      VARCHAR2(4),
  SRPDAT     VARCHAR2(7),
  MK         VARCHAR2(10),
  TXDAT      VARCHAR2(16),
  TXEMP      VARCHAR2(10),
  TXCO       VARCHAR2(2),
  TXMCH      VARCHAR2(30),
  TUBELNGD   VARCHAR2(4),
  CSTCEN     VARCHAR2(6),
  PMSECT     VARCHAR2(4),
  EQENM      VARCHAR2(100),
  PURNO      VARCHAR2(8),
  CHKNO      VARCHAR2(45),
  TRNDAT2    VARCHAR2(16),
  TXEMP2     VARCHAR2(10),
  TRNMK2     VARCHAR2(2),
  CSTCO      VARCHAR2(2)
)
;

prompt
prompt Creating view V0NKDG01
prompt ======================
prompt
create or replace view v0nkdg01 as
select "CO","PMFCT","PMSECT","MNTCO","MNTFCT","MNTSECT","TXTM" From t0nkdg0b;

prompt
prompt Creating package P0NKDG01
prompt =========================
prompt
CREATE OR REPLACE PACKAGE p0nkdg01 as
  /*  本package為全企業所有主機共用(不含tprs05)  */

 
 
  function get_eqnm(in_co in varchar2, in_pld in varchar2, in_eqno in varchar2) return varchar2;
  --  公司、廠處、部門、路線代號取路線名稱  --add by T007(2014.11.17)
  function get_waynm(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2;

  
 
  --
 
  -- 取date_min1,date_min2之間隔分鐘
  function sec_bet(date_sec1 in varchar2, date_sec2 in varchar2)
    return number;
  --

  /*判斷禮拜幾 97.08.27*/
  function f_weekday(p_date in varchar2) return varchar2;

  /* rndchar : 產生亂數字元函數  2009.08.19*/
  function rndchar return varchar2;

 
  /* f0a:t0nkdg0a代碼取名稱 */
  --p_dtid='1' : 設備類別
  function f0a(p_dtid in varchar2, p_id in varchar2) return varchar2;

  

  /* f_mpznm:公司、生產廠、製程區代號取製程區名稱  101.08.03*/
  function f_mpznm(p_co varchar2, p_pmfct varchar2, p_mpz varchar2)
    return varchar2;

  /* f_mpsysnm:公司、生產廠、製程區代號、製程區系統代號、取製程區系統名稱  101.08.03*/
  function f_mpsysnm(p_co    varchar2,
                     p_pmfct varchar2,
                     p_mpz   varchar2,
                     p_mpsys varchar2) return varchar2;

  /* get_eql:取設備基準上下限  101.08.03*/
  function get_eql(p_opco  varchar2,
                   p_oppld varchar2,
                   p_opdp  varchar2,
                   p_wayid varchar2,
                   p_sqno  varchar2,
                   p_fun   varchar2,
                   p_chkkd varchar2,
                   p_it    varchar2,
                   p_chkit varchar2,
                   p_stdid varchar2,
                   p_type  varchar2) return number;

  

 
  /* isChar:含英文或符號字元 101.11.13*/
  FUNCTION isChar(p_IN IN VARCHAR2) RETURN boolean;

 



  
  /* f_eqkd:取設備類別 102.03.05 */
  function f_eqkd(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2;

  /* f_eqty:取設備型式 102.03.05 */
  function f_eqty(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2;

  

  /* f_mylengthb:取字串長 102.05.24 */
  function f_mylengthb(p_str varchar2) return number;



  /* f_eqpmsect:取設備生產課 103.04.22 */
  function f_eqpmsect(p_co varchar2,p_pmfct varchar2,p_eqno varchar2) return varchar2;

  
  --檢查週期  add by T007(2014.11.28)
  procedure p_chk_cycqty(i_cycqty number, i_cycun varchar2, o_msg out varchar2);
  --公司、廠處、部門、路線代號取週期數量*/  --add by T058(2015.06.09)
  function get_cycqty(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 ;
  --公司、廠處、部門、路線代號取週期單位*/  --add by T058(2015.06.09)
  function get_cycun(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 ;
  --公司、廠處、設備取設備名稱*/  --add by T058(2015.06.15)
  function get_egnm(in_co in varchar2, in_pld in varchar2,in_egno in varchar2) return VARCHAR2;

end p0nkdg01;
/

prompt
prompt Creating view V0NKDG05
prompt ======================
prompt
CREATE OR REPLACE VIEW V0NKDG05 AS
SELECT  a.opco, a.oppld,a.opdp,a. wayid,P0NKDG01.get_waynm(a.opco,a.oppld,a.opdp,a.wayid) waynm
                  ,P0NKDG01.get_cycqty(a.opco,a.oppld,a.opdp,a.wayid) cycqty
                  ,P0NKDG01.get_cycun(a.opco,a.oppld,a.opdp,a.wayid) cycun
                  ,b.sqno,b.ctlptid,c.it,c.co,c.pmfct
                  ,c.eqno,a.fun,c.chkkd1 ,c.chkkd2 ,c.chkkd3
  FROM T0NKDGm5 A,T0NKDGD5_1 B,T0NKDGD5_2 c
WHERE A.OPCO=B.OPCO
AND A.OPPLD=A.OPPLD
AND A.OPDP=B.OPDP
AND A.WAYID= B.WAYID
AND b.OPCO=c.OPCO
AND b.OPPLD=c.OPPLD
AND b.OPDP=c.OPDP
AND b.WAYID= c.WAYID
AND b.SQNO=c.SQNO
ORDER BY a.opco, a.oppld,a.opdp, a. wayid ,a.waynm  ,a.cycqty,a.cycun ,b.sqno ,b.ctlptid
                 ,c.it ,c.co ,c.pmfct  ,c.eqno;

prompt
prompt Creating view V0NKDGM5
prompt ======================
prompt
create or replace view v0nkdgm5 as
select a.opco,a.oppld, a.opdp, a.wayid,a.fun ,a.cycqty,a.cycun,
b.sqno,b.ctlptid,c.it,c.co,c.pmfct,c.mpz,c.mpsys,c.eqno,c.eqnm,c.chkkd1 chkkd,e.chkit,e.itnm,e.stdid,e.stdnm,e.un,e.upl,e.ll,e.judgeitr
from t0nkdgm5 a,t0nkdgd5_1 b,t0nkdgd5_2 c,t0nkdgd2_1 d,t0nkdgd2_3 e
 where a.opco=b.opco
and a.oppld=b.oppld
and a.opdp=b.opdp
and a.wayid=b.wayid
and b.opco=c.opco
and b.oppld=c.oppld
and b.opdp=c.opdp
and b.wayid=c.wayid
and b.sqno=c.sqno
and c.opco=d.opco
and c.oppld=d.oppld
and c.opdp=d.opdp
and c.eqno=d.eqno
and c.chkkd1=d.chkkd
and a.cycqty=d.cycqty
and a.cycun=d.cycun
and d.opco=e.opco
and d.oppld=e.oppld
and d.opdp=e.opdp
and d.eqno=e.eqno
and d.chkkd=e.chkkd
and d.co=e.co
and d.pmfct=e.pmfct
union all
select a.opco,a.oppld, a.opdp, a.wayid,a.fun ,a.cycqty,a.cycun,
b.sqno,b.ctlptid,c.it,c.co,c.pmfct,c.mpz,c.mpsys,c.eqno,c.eqnm,c.chkkd2 chkkd,e.chkit,e.itnm,e.stdid,e.stdnm,e.un,e.upl,e.ll,e.judgeitr
from t0nkdgm5 a,t0nkdgd5_1 b,t0nkdgd5_2 c,t0nkdgd2_1 d,t0nkdgd2_3 e
 where  c.chkkd2 is not null and  a.opco=b.opco
and a.oppld=b.oppld
and a.opdp=b.opdp
and a.wayid=b.wayid
and b.opco=c.opco
and b.oppld=c.oppld
and b.opdp=c.opdp
and b.wayid=c.wayid
and b.sqno=c.sqno
and c.opco=d.opco
and c.oppld=d.oppld
and c.opdp=d.opdp
and c.eqno=d.eqno
and c.chkkd2=d.chkkd
and a.cycqty=d.cycqty
and a.cycun=d.cycun
and d.opco=e.opco
and d.oppld=e.oppld
and d.opdp=e.opdp
and d.eqno=e.eqno
and d.chkkd=e.chkkd
and d.co=e.co
and d.pmfct=e.pmfct
union all
select a.opco,a.oppld, a.opdp, a.wayid,a.fun ,a.cycqty,a.cycun,
b.sqno,b.ctlptid,c.it,c.co,c.pmfct,c.mpz,c.mpsys,c.eqno,c.eqnm,c.chkkd3 chkkd,e.chkit,e.itnm,e.stdid,e.stdnm,e.un,e.upl,e.ll,e.judgeitr
from t0nkdgm5 a,t0nkdgd5_1 b,t0nkdgd5_2 c,t0nkdgd2_1 d,t0nkdgd2_3 e
 where c.chkkd3 is not null and  a.opco=b.opco
and a.oppld=b.oppld
and a.opdp=b.opdp
and a.wayid=b.wayid
and b.opco=c.opco
and b.oppld=c.oppld
and b.opdp=c.opdp
and b.wayid=c.wayid
and b.sqno=c.sqno
and c.opco=d.opco
and c.oppld=d.oppld
and c.opdp=d.opdp
and c.eqno=d.eqno
and c.chkkd3=d.chkkd
and a.cycqty=d.cycqty
and a.cycun=d.cycun
and d.opco=e.opco
and d.oppld=e.oppld
and d.opdp=e.opdp
and d.eqno=e.eqno
and d.chkkd=e.chkkd
and d.co=e.co
and d.pmfct=e.pmfct
order by sqno,it,chkkd,chkit,stdid;

prompt
prompt Creating package body P0NKDG01
prompt ==============================
prompt
CREATE OR REPLACE PACKAGE body p0nkdg01 as
  /*  本package為全企業所有主機共用(不含tprs05)  */
  --


  /* get_eqnm:公司、事業部代號取事業部名稱*/  --add by T007(2014.11.03)
  function get_eqnm(in_co in varchar2, in_pld in varchar2, in_eqno in varchar2) return varchar2 is
    wk_eqnm   varchar2(100);
  begin
    select eqnm into wk_eqnm
      from t0nkpme3
     where co=in_co and
           pmfct=in_pld and
           eqno=in_eqno;
    --
    return wk_eqnm;
  exception
    when others then
         return wk_eqnm;
  end get_eqnm;
  --
  /* get_waynm:公司、廠處、部門、路線代號取路線名稱*/  --add by T007(2014.11.17)
  function get_waynm(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 is
    wk_waynm   varchar2(100);
    --
    cursor c_dg05 is
           select waynm
             from t0nkdgm5
            where opco=in_co and
                  oppld=in_pld and
                  opdp=in_dp and
                  wayid=in_wayid 
            order by nvl(paubegdat,'9999999') desc,nvl(paupaudat,'9999999') desc;
  begin
    open c_dg05;
    fetch c_dg05 into wk_waynm;
    if c_dg05%notfound then
       wk_waynm := '';
    end if;
    close c_dg05;
    --
    return wk_waynm;
  exception
    when others then
         return wk_waynm;
  end get_waynm;
  --


  

 
  
  --  **************************************************************************
 
  --  **************************************************************************
  -- 取date_min1,date_min2之間隔秒數
  /*function sec_bet(date_sec1 in varchar2, date_sec2 in varchar2)
    return number is
    p_date_sec1 varchar2(13);
    wrk_xdays   number;
    wrk_sec1    number;
    wrk_sec2    number;
    swt_err     varchar2(1);
    wrk_date_1  varchar2(7);
    wrk_date_2  varchar2(7);
  begin
    p_date_sec1 := substr(to_char(to_number(date_sec1) + 19110000000000),
                          2,
                          13);
    --計算date_sec1與 2000/01/01 00:00之間隔秒數
    --天數差換算成秒數
    wrk_date_1 := '0000101';
    wrk_date_2 := substr(p_date_sec1, 1, 7);
    ystd.bt_date(wrk_date_1, wrk_date_2, wrk_xdays, swt_err);
    wrk_sec1 := abs(wrk_xdays * 24 * 60 * 60);
    --
    --小時數差換算成秒數
    wrk_sec1 := wrk_sec1 + to_number(substr(p_date_sec1, 8, 2)) * 60 * 60;
    --
    --分鐘數差換算成秒數
    wrk_sec1 := wrk_sec1 + to_number(substr(p_date_sec1, 10, 2)) * 60;
    --
    wrk_sec1 := wrk_sec1 + to_number(substr(p_date_sec1, 12, 2));
    --
    --計算date_sec1與 2000/01/01 00:00之間隔秒數
    --天數差換算成秒數
    wrk_date_1 := '0000101';
    wrk_date_2 := substr(date_sec2, 1, 7);
    ystd.bt_date(wrk_date_1, wrk_date_2, wrk_xdays, swt_err);
    wrk_sec2 := abs(wrk_xdays * 24 * 60 * 60);
    --
    --小時數差換算成秒數
    wrk_sec2 := wrk_sec2 + to_number(substr(date_sec2, 8, 2)) * 60 * 60;
    --
    --分鐘數差換算成秒數
    wrk_sec2 := wrk_sec2 + to_number(substr(date_sec2, 10, 2)) * 60;
    --
    wrk_sec2 := wrk_sec2 + to_number(substr(date_sec2, 12, 2));
    --
    return abs(wrk_sec2 - wrk_sec1);
  end;*/

  /*判斷禮拜幾 97.08.27*/
  function f_weekday(p_date in varchar2) return varchar2 is
    val1  number;
    val2  number;
    val2x number;
    val3  number;
    val4  number;
    val5  number;
    val6  number;
    val7  number;
    val8  number;
    val9  number;
    val0  number;
  begin
    val1  := to_number(substr(p_date, 6, 2));
    val2  := to_number(substr(p_date, 4, 2));
    val2x := val2;
    val3  := to_number(substr(p_date, 1, 3)) + 1911;
    if (val2 = 1) then
      val2x := 13;
      val3  := val3 - 1;
    end if;
    if (val2 = 2) then
      val2x := 14;
      val3  := val3 - 1;
    end if;
    val4 := trunc(((val2x + 1) * 3) / 5);
    val5 := trunc(val3 / 4);
    val6 := trunc(val3 / 100);
    val7 := trunc(val3 / 400);
    val8 := val1 + (val2x * 2) + val4 + val3 + val5 - val6 + val7 + 2;
    val9 := trunc(val8 / 7);
    val0 := val8 - (val9 * 7);
    if val0 = 0 then
      return('六');
    elsif val0 = 1 then
      return('日');
    elsif val0 = 2 then
      return('一');
    elsif val0 = 3 then
      return('二');
    elsif val0 = 4 then
      return('三');
    elsif val0 = 5 then
      return('四');
    elsif val0 = 6 then
      return('五');
    else
      return('?');
    end if;
  end f_weekday;

  

  /* rndchar : 產生亂數字元函數  2009.08.19*/
  function rndchar return varchar2 is
    wrk_rndchar varchar2(1);
  begin
    select decode(trunc(dbms_random.value * 36) + 1,
                  1,
                  '1',
                  2,
                  '2',
                  3,
                  '3',
                  4,
                  '4',
                  5,
                  '5',
                  6,
                  '6',
                  7,
                  '7',
                  8,
                  '8',
                  9,
                  '9',
                  10,
                  '0',
                  11,
                  'A',
                  12,
                  'B',
                  13,
                  'C',
                  14,
                  'D',
                  15,
                  'E',
                  16,
                  'F',
                  17,
                  'G',
                  18,
                  'H',
                  19,
                  'I',
                  20,
                  'J',
                  21,
                  'K',
                  22,
                  'L',
                  23,
                  'M',
                  24,
                  'N',
                  25,
                  'O',
                  26,
                  'P',
                  27,
                  'Q',
                  28,
                  'R',
                  29,
                  'S',
                  30,
                  'T',
                  31,
                  'U',
                  32,
                  'V',
                  33,
                  'W',
                  34,
                  'X',
                  35,
                  'Y',
                  36,
                  'Z',
                  '?')
      into wrk_rndchar
      from dual;
    return wrk_rndchar;
  end rndchar;

  /* IDtoNID : 身份證字號轉NOTEID  2010.05.02*/
  function IDtoNID(p_ID varchar2) return varchar2 is
    --wrk_noteid varchar2(10);
  begin
    --select empid into wrk_noteid from v0nbfc00@temp where idno = p_ID;
    return p_ID;
  end;

  /* skip_holiday : p_date_s加p_xdays工作天  2011.04.01*/
  --p_skip:Y:跳過 null:不跳過
  

  /* f0a:t0nkdg0a代碼取名稱 */
  function f0a(p_dtid in varchar2, p_id in varchar2) return varchar2 is
    wrk_nm t0nkdg0a.nm%type;
    --p_dtid='1' : 設備類別
  begin
    
      select nm
        into wrk_nm
        from t0nkdg0a
       where dtid = p_dtid
         and id = p_id;
      return wrk_nm;
  exception
    when others then
      return null;
  end f0a;

  
  --

  /* f_mpznm:公司、生產廠、製程區代號取製程區名稱  101.08.03*/
  function f_mpznm(p_co varchar2, p_pmfct varchar2, p_mpz varchar2)
    return varchar2 is
    wrk_mpznm t0nkpme0.cnm%type;
  begin
    begin
      select cnm
        into wrk_mpznm
        from t0nkpme0
       where co = p_co
         and pmfct = p_pmfct
         and mpzid = p_mpz;
      return wrk_mpznm;
    exception
      when others then
        return '';
    end;
  end f_mpznm;

  /* f_mpsysnm:公司、生產廠、製程區代號、製程區系統代號、取製程區系統名稱  101.08.03*/
  function f_mpsysnm(p_co    varchar2,
                     p_pmfct varchar2,
                     p_mpz   varchar2,
                     p_mpsys varchar2) return varchar2 is
    wrk_mpsysnm t0nkpme1.cnm%type;
  begin
    begin
      select cnm
        into wrk_mpsysnm
        from t0nkpme1
       where co = p_co
         and pmfct = p_pmfct
         and mpzid = p_mpz
         and mpsysid = p_mpsys;
      return wrk_mpsysnm;
    exception
      when others then
        return '';
    end;
  end f_mpsysnm;

  /* get_eql:取設備基準上下限  101.08.03*/
  function get_eql(p_opco  varchar2,
                   p_oppld varchar2,
                   p_opdp  varchar2,
                   p_wayid varchar2,
                   p_sqno  varchar2,
                   p_fun   varchar2,
                   p_chkkd varchar2,
                   p_it    varchar2,
                   p_chkit varchar2,
                   p_stdid varchar2,
                   p_type  varchar2) return number is
    --p_type U:上限 L:下限
    wrk_cycqty t0nkdgm5.cycqty%type;
    wrk_cycun  t0nkdgm5.cycun%type;
    wrk_eqno   t0nkdgd5_2.eqno%type;
    wrk_pmfct  t0nkdgd5_2.pmfct%type;
    wrk_co     t0nkdgd5_2.co%type;
    wrk_upl    number;
    wrk_ll     number;
  begin

    begin
      select cycqty, cycun
        into wrk_cycqty, wrk_cycun
        from t0nkdgm5
       where opco = p_opco
         and oppld = p_oppld
         and opdp = p_opdp
         and wayid = p_wayid;
    exception
      when others then
        wrk_cycqty := null;
        wrk_cycun  := null;
    end;
    --
    --取設備編號、設備名稱
    begin
      select eqno, PmFct, co
        into wrk_eqno, wrk_pmfct, wrk_co
        from T0NKDGD5_2
       where opco = p_opco
         and OpPld = p_oppld
         and OpDp = p_opdp
         and WayId = p_wayid
         and Sqno = p_sqno
         and It = p_it;
    exception
      when others then
        wrk_eqno  := null;
        wrk_pmfct := null;
        wrk_co    := null;
    end;
    --

    begin
      select upl, ll
        into wrk_upl, wrk_ll
        from t0nkdgd2_3
       where OPCO = p_opco
         and OPPLD = p_oppld
         and OPDP = p_opdp
         and FUN = p_fun
         and CHKKD = p_chkkd
       --  and CYCQTY = wrk_cycqty
       --  and CYCUN = wrk_cycun
         and CO = wrk_co
         and PMFCT = wrk_pmfct
         and EQNO = wrk_eqno
         and CHKIT = p_chkit
         and STDID = p_stdid;
    exception
      when others then
        wrk_upl := null;
        wrk_ll  := null;
    end;

    if p_type = 'U' then
      return wrk_upl;
    elsif p_type = 'L' then
      return wrk_ll;
    end if;
  end get_eql;

 
  

  /* isChar:含英文或符號字元 101.11.13*/
  FUNCTION isChar(p_IN IN VARCHAR2) RETURN boolean IS
    WRK_NUM NUMBER(10) := 0;
  BEGIN

    WRK_NUM := instr(translate(upper(p_IN),
                               'ABCDEFGHIJKLMNOPQRSTUVWXYZ+"/\*@!$%&^<>?#',
                               '#########################################'),
                     '#');
    if WRK_NUM > 0 THEN
      --若傳入字串含英文字等特殊字元,回傳 true
      RETURN true;
    ELSE
      RETURN false;
    end IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN false;
  END isChar;

  /* P_APPLY_COMMON:套用共通性基準 101.11.26*/
  
  

 

  

  /* f_eqkd:取設備類別 102.03.05 */
  function f_eqkd(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2 is
    wrk_eqkd varchar2(10);
  begin
    select eqkd
      into wrk_eqkd
      from t0nkpme3
     where co = p_co
       and pmfct = p_pmfct
       and eqno = p_eqno;
    return wrk_eqkd;
  exception
    when others then
      return null;
  end f_eqkd;

  /* f_eqty:取設備型式 102.03.05 */
  function f_eqty(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2 is
    wrk_eqty varchar2(10);
  begin
    select eqty
      into wrk_eqty
      from t0nkpme3
     where co = p_co
       and pmfct = p_pmfct
       and eqno = p_eqno;
    return wrk_eqty;
  exception
    when others then
      return null;
  end f_eqty;

  

  /* f_mylengthb:取字串長 102.05.24 */
  function f_mylengthb(p_str varchar2) return number is
  begin
    return lengthb(p_str);
  end f_mylengthb;

  


  /* f_eqpmsect:取設備生產課 103.04.22 */
  function f_eqpmsect(p_co varchar2,p_pmfct varchar2,p_eqno varchar2) return varchar2 is
    wrk_pmsect t0nkpme3.pmsect%type;
  begin
    select nvl(pmsect,pmfct)
      into wrk_pmsect
      from t0nkpme3
     where co=p_co
       and pmfct=p_pmfct
       and eqno=p_eqno;
    return wrk_pmsect;
  exception
    when others then
      return p_pmfct;
  end f_eqpmsect;


  
  --檢查週期  add by T007(2014.11.28)
  procedure p_chk_cycqty(i_cycqty number, i_cycun varchar2, o_msg out varchar2) is
  begin
    if i_cycun not in ('H','D','W','M') then
       o_msg := '週期代號只能輸入H,D,W,M';
       return;
    end if;
    --小時
    if    i_cycun='H' then
          if mod(i_cycqty,24)=0 then
             o_msg := '週期'||i_cycqty||i_cycun||','||'應修改為'||to_char(i_cycqty/24)||'D';
             return;
          else
             o_msg := '';
             return;
          end if;
    --日
    elsif i_cycun='D' then
          if mod(i_cycqty,7)=0 then
             o_msg := '週期'||i_cycqty||i_cycun||','||'應修改為'||to_char(i_cycqty/7)||'W';
             return;
          else
             o_msg := '';
             return;
          end if;
    --週
    elsif i_cycun='W' then
          if mod(i_cycqty,4)=0 then
             o_msg := '週期'||i_cycqty||i_cycun||','||'應修改為'||to_char(i_cycqty/4)||'M';
             return;
          else
             o_msg := '';
             return;
          end if;
    else
          o_msg := '';
          return;
    end if;
  end;
 

  --公司、廠處、部門、路線代號取週期數量 單位*/  --add by T058(2015.06.09)
  function get_cycqty(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 is
    wk_cycqty   VARCHAR2(3);
    --
    cursor c_dg05 is
           select to_char(cycqty)
             from t0nkdgm5
            where opco=in_co and
                  oppld=in_pld and
                  opdp=in_dp and
                  wayid=in_wayid 
            order by nvl(paubegdat,'9999999') desc,nvl(paupaudat,'9999999') desc;
  begin
    open c_dg05;
    fetch c_dg05 into wk_cycqty;
    if c_dg05%notfound then
       wk_cycqty  := '';
    end if;
    close c_dg05;
    --
    return wk_cycqty ;
  exception
    when others then
         return wk_cycqty ;
  end get_cycqty;
    --公司、廠處、部門、路線代號取週期單位*/  --add by T058(2015.06.09)
  function get_cycun(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 is
    wk_cycun   VARCHAR2(2);
    --
    cursor c_dg05 is
           select cycun
             from t0nkdgm5
            where opco=in_co and
                  oppld=in_pld and
                  opdp=in_dp and
                  wayid=in_wayid 
            order by nvl(paubegdat,'9999999') desc,nvl(paupaudat,'9999999') desc;
  begin
    open c_dg05;
    fetch c_dg05 into wk_cycun;
    if c_dg05%notfound then
       wk_cycun  := '';
    end if;
    close c_dg05;
    --
    return wk_cycun ;
  exception
    when others then
         return wk_cycun ;
  end get_cycun;
  --------------------------------
    --公司、廠處、設備取設備名稱*/  --add by T058(2015.06.15)
  function get_egnm(in_co in varchar2, in_pld in varchar2,in_egno in varchar2) return varchar2 is
    wk_egnm   VARCHAR2(40);
    --
    cursor c_me3 is
           SELECT substrb(eqnm,1,40)
             from T0NKPME3
            where co   = in_co
              AND pmfct  = in_pld
              AND eqno   = in_egno;
  begin
    open c_me3;
      fetch c_me3 into wk_egnm;
        if c_me3%notfound then
           wk_egnm  := '';
        end if;
    close c_me3;
    --
    return wk_egnm ;
  exception
    when others then
         return wk_egnm ;
  end get_egnm;
  --------------------------------
end p0nkdg01;
/
@@t0nkdg04
@@t0nkdgm5
@@t0nkdgd5_1
@@t0nkdgd5_2
@@t0nkdg0a
@@t0nkdg09
@@t0nkdgm2
@@t0nkdgd2_1
@@t0nkpme0
@@t0nkpme1
@@t0nkpme3
@@e3.sql
spool off
