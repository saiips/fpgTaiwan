﻿prompt PL/SQL Developer import file
prompt Created on 2018年5月28日 by n000074170
set feedback off
set define off
prompt Loading T0NKDG0A...
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('A', 'M', '保養', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('A', 'F', '消防', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('A', 'P', '製程', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('A', 'E', '專業', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('A', 'S', '工安', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'F1', '外觀自主檢查', '1010802');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'P1', '製程巡檢', '1010808');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'F2', '位置構造檢查', '1040310');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'F3', '簡易性能測試', '1040310');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'F4', '年度檢修申報', '1040314');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'P2', '專業巡檢', '1010809');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'M1', '預防巡檢', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('B', 'P3', '抄錶巡檢', '1020520');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('C', 'M', '月', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('C', 'W', '週', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('C', 'H', '小時', '1010710');
insert into T0NKDG0A (DTID, ID, NM, TXDAT)
values ('C', 'D', '天', '1010710');
commit;
prompt 17 records loaded
set feedback on
set define on
prompt Done.
