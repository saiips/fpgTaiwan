﻿prompt PL/SQL Developer import file
prompt Created on 2018年5月28日 by n000074170
set feedback off
set define off
prompt Loading T0NKPME0...
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '87', '400', '重合區', 'polymerization unit', '87BA', '1020205181731', 'N000073434', null, null);
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '87', '700', '成品儲槽區', 'pellet silos', '87BA', '1020205181731', 'N000073434', null, null);
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '87', '800', '製粒區', 'pelletizing unit', '87BA', '1020205181731', 'N000073434', null, null);
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '87', '87BA', 'LLDPE', 'LLDPE', null, '1020918101825', 'N000127250', null, null);
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '87', '600', '600區', '600', '87BA', '1030818115719', 'N000147720', '1', 'MLFPCPOL1082');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '87', '87BALLDPE', '三廠共用倉庫', 'THREE FACTORIES SHARE THE WAREHOUSE', '87BA', '1070328150439', 'N000087327', '1', 'MLFPCCMTN8147');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '12C1A', '技術處碳纖組原絲試驗工廠', '12K pilot', '2C1A', '1020726153804', 'N000096236', null, null);
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '2C1A', '技術處CF組', 'CARBON FIBER', '2C1A', '1031231145033', 'N000148355', '1', 'JWFPCTRL0126');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '2C3A', '技術處SAP組', 'SAP GROUP', '2C3A', '1031226083634', 'N000148355', '1', 'JWFPCTRL0126');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '12C2A', '技術處纖維組', 'acrylic fiber group', '2C2A', '1030829141059', 'N000019210', '1', 'JWFPCMTNC7109');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '600', '600區', '600 AREA', null, '1040929183853', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '800', '800區', '800 AREA', 'P9BW', '1050113131250', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '100', '100區', '100 AREA', 'P9BF', '1040818173227', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '500', '500區', '500 AREA', null, '1041120105535', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '700', '700區', '700 AREA', null, '1041005182143', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '400', '400區', '400 AREA', null, '1041005182143', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '2C0A', '技術處處務', 'OFFICE', '2C0A', '1031229153603', 'N000094892', '1', 'JWFPCMTNC7103');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '2C2A', '技術處纖維組', 'acrylic fiber group', '2C2A', '1030620145356', 'N000019212', '1', 'JWFPCMTNC7209');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '2CAB', '技術處技術課(分析)', 'Technical group', '2CAB', '1031225190545', 'N000148355', '1', 'JWFPCTRL0126');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', '2C', '2CAC', '技術處技術課(檢棉)', 'Technical group', '2CAC', '1031225190545', 'N000148355', '1', 'JWFPCTRL0126');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '200', '200區', '200 AREA', null, '1040909171701', 'N000003621', '1', 'SKFPCPOMX3168');
insert into T0NKPME0 (CO, PMFCT, MPZID, CNM, ENM, CSTCEN, TXDAT, TXEMP, TXCO, TXMCH)
values ('1', 'P9', '300', '300區', '300 AREA', 'P9BD', '1041027081705', 'N000003621', '1', 'SKFPCPOMX3168');
commit;
prompt 22 records loaded
set feedback on
set define on
prompt Done.
