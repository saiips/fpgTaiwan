﻿prompt PL/SQL Developer import file
prompt Created on 2018年5月28日 by n000074170
set feedback off
set define off
prompt Loading T0NKDGM2...
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F3', 'IH', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FB', 'CI', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FJ', 'GS', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'R2', 'RL', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'S2', 'IS', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W3', 'SP', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W2', 'DC', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F4', 'OH', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F6', 'SH', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FD', 'WG', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'R2', 'EI', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W2', 'DP', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F1', 'HD', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F1', 'SA', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FJ', 'CP', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'S3', 'FP', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F1', 'HB', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FJ', 'GF', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'R2', 'RI', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W2', 'SP', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W3', 'ES', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F1', 'WD', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F6', 'BL', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FJ', 'GT', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'R1', 'EL', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W2', 'TP', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F1', 'HG', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F5', 'SE', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'F6', 'BH', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'W2', 'HW', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'F', 'F1', 1, 'M', 'FB', 'SH', '1', 'P9', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'F1', 'HD', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'W2', 'HW', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'F1', 'WD', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'R2', 'RL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'F3', 'IH', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'FD', 'WG', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'R1', 'EL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'R2', 'EI', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'W3', 'SP', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 3, 'M', 'F4', 'OH', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 3, 'M', 'FD', 'WG', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'F1', 'HG', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'R2', 'RL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'F3', 'TO', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'F4', 'OH', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'W2', 'TL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'F1', 'HG', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'R1', 'EL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'W2', 'HW', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 3, 'M', 'W2', 'HW', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'F1', 'HD', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'FD', 'WG', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 1, 'M', 'R2', 'EI', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 1, 'M', 'R2', 'RL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 1, 'M', 'W3', 'SP', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 3, 'M', 'F3', 'TO', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'R2', 'EI', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'F3', 'IH', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 3, 'M', 'F1', 'HG', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'W2', 'TL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 1, 'M', 'R1', 'EL', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F3', 6, 'M', 'F3', 'IH', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'F1', 'WD', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'F3', 'TO', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F1', 1, 'M', 'W3', 'SP', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F', 'F2', 6, 'M', 'F4', 'OH', '1', '2C', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'SW', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'W2', 'HW', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'R2', 'RI', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'AC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'CV', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'SH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'W2', 'SP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'FD', 'WG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F4', 'CH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VA', 'PV', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'BA', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'CS', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', '27', '*', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'PG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F1', 'HG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'EC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'SH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'R1', 'EL', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'W2', 'DP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 6, 'M', 'F3', 'IH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'FF', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'FA', 'CE', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'PL', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'CY', 'MH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'SE', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'SI', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'W3', 'SP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 1, 'M', 'W3', 'SP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'RT', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'AD', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'DB', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'NO', 'SN', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'SE', '1', '87', null, null, null, null);
commit;
prompt 100 records committed...
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'R2', 'EI', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'AT', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'W3', 'SP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F1', 'HD', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'R2', 'RI', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 1, 'M', 'R1', 'EL', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F1', 'HG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F5', 'EC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'GB', 'GR', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'DB', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'PG', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'SE', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'GL', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'WA', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'R1', 'EL', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F1', 'HD', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F4', 'CH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F1', 'HG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'R2', 'EI', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F4', 'CH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'W2', 'HW', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'AT', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'EC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'CY', 'MH', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'GL', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'SL', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'KN', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', '24', '*', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VA', 'PV', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 8, 'M', 'RP', '00', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F3', 'IH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'W2', 'SP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'FD', 'WG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F1', 'WD', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 1, 'M', 'R2', 'EI', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F5', 'AC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F5', 'SH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'FD', 'WG', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'FS', 'IC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', '23', '*', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'SA', 'NT', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 8, 'M', 'DP', 'FR', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 8, 'M', 'DP', 'SS', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 8, 'M', 'RI', '00', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'W2', 'DP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F1', 'WD', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'SW', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F4', 'OH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F3', 'IH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'W2', 'HW', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'AD', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'DU', 'BF', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HB', 'EH', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'PL', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'R2', 'EL', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'SA', 'HP', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'WA', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'SM', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'DU', 'BF', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'EM', 'AC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'RT', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'SA', 'HP', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F4', 'OH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'AC', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F1', 1, 'M', 'F5', 'CV', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F2', 6, 'M', 'F5', 'SE', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F4', 'OH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'F', 'F3', 3, 'M', 'F5', 'CV', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'SA', 'NT', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'FS', 'IC', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'SL', '*', '*', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HB', 'EH', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'HE', 'FF', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VC', 'BA', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', '25', '*', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 2, 'M', 'VE', 'SM', '1', '87', null, null, null, null);
insert into T0NKDGM2 (OPCO, OPPLD, OPDP, FUN, CHKKD, CYCQTY, CYCUN, EQKD, EQTY, CO, PMFCT, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'P', 'P1', 8, 'M', 'DI', '99', '1', '87', null, null, null, null);
commit;
prompt 177 records loaded
set feedback on
set define on
prompt Done.
