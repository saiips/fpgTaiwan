﻿prompt PL/SQL Developer import file
prompt Created on 2018年5月28日 by n000074170
set feedback off
set define off
prompt Loading T0NKDGM5...
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'POM-01M', '巡檢測試路線01', 'F', 1, 'M', null, null, null, '1070503', '1070625', null, null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'POM-02M', '巡檢測試路線02', 'F', 6, 'M', null, null, null, '1070124', '1070725', null, null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'POM-05M', '巡檢測試路線05', 'F', 6, 'M', null, null, null, '1070322', '1070925', null, null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', '200', '100及200區', 'F', 3, 'M', null, null, null, null, '1070625', 'Y', null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', '700', '700區', 'F', 3, 'M', null, null, null, null, '1070625', 'Y', null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', '600', '300及600區', 'F', 3, 'M', null, null, null, null, '1070625', 'Y', null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', '800', '公用區', 'F', 3, 'M', null, null, null, null, '1070625', 'Y', null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'POM-04M', '巡檢測試路線04', 'F', 3, 'M', null, null, null, '1070321', '1070625', null, null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', 'P9', 'P9BA', 'POM-03M', '巡檢測試路線03', 'F', 1, 'M', null, null, null, '1070508', '1070625', null, null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '2C', '2C1A', 'F1-TL', '纖維組消防外觀巡檢', 'F', 1, 'M', null, null, null, '1070511', '1070625', null, null, null, null, null, null, null, null);
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'C-D', '700區每日', 'P', 2, 'D', '1070201', '1070212', null, '1070510', '1070512', 'Y', null, null, 'Y', '1', 'N000141828', 'MLFPCPOL0087', '1070510100120');
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'LL-4', '消防類巡檢', 'F', 1, 'M', null, null, null, '1070503', '1070625', null, null, null, null, '1', 'N000147720', 'MLFPCPOL1082', '1070503140125');
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'LL-F2-1', '消防類巡檢', 'F', 6, 'M', null, null, null, '1070411', '1071025', null, null, null, null, '1', 'N000147720', 'MLFPCPOL1082', '1070411140139');
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'LL-F3-1', '消防類巡檢', 'F', 3, 'M', null, null, null, '1070331', '1070625', null, null, null, null, '1', 'N000147720', 'MLFPCPOL1082', '1070331180127');
insert into T0NKDGM5 (OPCO, OPPLD, OPDP, WAYID, WAYNM, FUN, CYCQTY, CYCUN, PAUBEGDAT, PAUPAUDAT, DDUHOL, LSTCHKDAT, NXTCHKDAT, APSTS, FOLCNT, NTITM, ABMK, TXCO, TXEMP, TXMCH, TXTM)
values ('1', '87', '87BA', 'LL-F3-2', '消防類巡檢', 'F', 3, 'M', null, null, null, '1070331', '1070625', null, null, null, null, '1', 'N000147720', 'MLFPCPOL1082', '1070331180128');
commit;
prompt 15 records loaded
set feedback on
set define on
prompt Done.
