CREATE OR REPLACE PACKAGE p0nkdg01 as
  /*  ��package�������~�Ҧ��D���@��(���ttprs05)  */

 
 
  function get_eqnm(in_co in varchar2, in_pld in varchar2, in_eqno in varchar2) return varchar2;
  --  ���q�B�t�B�B�����B���u�N�������u�W��  --add by T007(2014.11.17)
  function get_waynm(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2;

  
 
  --
 
  -- ��date_min1,date_min2�����j����
 /* function sec_bet(date_sec1 in varchar2, date_sec2 in varchar2)
    return number;*/
  --

  /*�P�_§���X 97.08.27*/
  function f_weekday(p_date in varchar2) return varchar2;

  /* rndchar : ���ͶüƦr�����  2009.08.19*/
  function rndchar return varchar2;

 
  /* f0a:t0nkdg0a�N�X���W�� */
  --p_dtid='1' : �]�����O
  function f0a(p_dtid in varchar2, p_id in varchar2) return varchar2;

  

  /* f_mpznm:���q�B�Ͳ��t�B�s�{�ϥN�����s�{�ϦW��  101.08.03*/
  function f_mpznm(p_co varchar2, p_pmfct varchar2, p_mpz varchar2)
    return varchar2;

  /* f_mpsysnm:���q�B�Ͳ��t�B�s�{�ϥN���B�s�{�Ϩt�ΥN���B���s�{�Ϩt�ΦW��  101.08.03*/
  function f_mpsysnm(p_co    varchar2,
                     p_pmfct varchar2,
                     p_mpz   varchar2,
                     p_mpsys varchar2) return varchar2;

  /* get_eql:���]�ư�ǤW�U��  101.08.03*/
  function get_eql(p_opco  varchar2,
                   p_oppld varchar2,
                   p_opdp  varchar2,
                   p_wayid varchar2,
                   p_sqno  varchar2,
                   p_fun   varchar2,
                   p_chkkd varchar2,
                   p_it    varchar2,
                   p_chkit varchar2,
                   p_stdid varchar2,
                   p_type  varchar2) return number;

  

 
  /* isChar:�t�^��βŸ��r�� 101.11.13*/
  FUNCTION isChar(p_IN IN VARCHAR2) RETURN boolean;

 



  
  /* f_eqkd:���]�����O 102.03.05 */
  function f_eqkd(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2;

  /* f_eqty:���]�ƫ��� 102.03.05 */
  function f_eqty(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2;

  

  /* f_mylengthb:���r��� 102.05.24 */
  function f_mylengthb(p_str varchar2) return number;



  /* f_eqpmsect:���]�ƥͲ��� 103.04.22 */
  function f_eqpmsect(p_co varchar2,p_pmfct varchar2,p_eqno varchar2) return varchar2;

  
  --�ˬd�g��  add by T007(2014.11.28)
  procedure p_chk_cycqty(i_cycqty number, i_cycun varchar2, o_msg out varchar2);
  --���q�B�t�B�B�����B���u�N�����g���ƶq*/  --add by T058(2015.06.09)
  function get_cycqty(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 ;
  --���q�B�t�B�B�����B���u�N�����g�����*/  --add by T058(2015.06.09)
  function get_cycun(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 ;
  --���q�B�t�B�B�]�ƨ��]�ƦW��*/  --add by T058(2015.06.15)
  function get_egnm(in_co in varchar2, in_pld in varchar2,in_egno in varchar2) return VARCHAR2;

end p0nkdg01;
/
CREATE OR REPLACE PACKAGE body p0nkdg01 as
  /*  ��package�������~�Ҧ��D���@��(���ttprs05)  */
  --


  /* get_eqnm:���q�B�Ʒ~���N�����Ʒ~���W��*/  --add by T007(2014.11.03)
  function get_eqnm(in_co in varchar2, in_pld in varchar2, in_eqno in varchar2) return varchar2 is
    wk_eqnm   varchar2(100);
  begin
    select eqnm into wk_eqnm
      from t0nkpme3
     where co=in_co and
           pmfct=in_pld and
           eqno=in_eqno;
    --
    return wk_eqnm;
  exception
    when others then
         return wk_eqnm;
  end get_eqnm;
  --
  /* get_waynm:���q�B�t�B�B�����B���u�N�������u�W��*/  --add by T007(2014.11.17)
  function get_waynm(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 is
    wk_waynm   varchar2(100);
    --
    cursor c_dg05 is
           select waynm
             from t0nkdgm5
            where opco=in_co and
                  oppld=in_pld and
                  opdp=in_dp and
                  wayid=in_wayid 
            order by nvl(paubegdat,'9999999') desc,nvl(paupaudat,'9999999') desc;
  begin
    open c_dg05;
    fetch c_dg05 into wk_waynm;
    if c_dg05%notfound then
       wk_waynm := '';
    end if;
    close c_dg05;
    --
    return wk_waynm;
  exception
    when others then
         return wk_waynm;
  end get_waynm;
  --


  

 
  
  --  **************************************************************************
 
  --  **************************************************************************
  -- ��date_min1,date_min2�����j����
  /*function sec_bet(date_sec1 in varchar2, date_sec2 in varchar2)
    return number is
    p_date_sec1 varchar2(13);
    wrk_xdays   number;
    wrk_sec1    number;
    wrk_sec2    number;
    swt_err     varchar2(1);
    wrk_date_1  varchar2(7);
    wrk_date_2  varchar2(7);
  begin
    p_date_sec1 := substr(to_char(to_number(date_sec1) + 19110000000000),
                          2,
                          13);
    --�p��date_sec1�P 2000/01/01 00:00�����j����
    --�ѼƮt���⦨����
    wrk_date_1 := '0000101';
    wrk_date_2 := substr(p_date_sec1, 1, 7);
    ystd.bt_date(wrk_date_1, wrk_date_2, wrk_xdays, swt_err);
    wrk_sec1 := abs(wrk_xdays * 24 * 60 * 60);
    --
    --�p�ɼƮt���⦨����
    wrk_sec1 := wrk_sec1 + to_number(substr(p_date_sec1, 8, 2)) * 60 * 60;
    --
    --�����Ʈt���⦨����
    wrk_sec1 := wrk_sec1 + to_number(substr(p_date_sec1, 10, 2)) * 60;
    --
    wrk_sec1 := wrk_sec1 + to_number(substr(p_date_sec1, 12, 2));
    --
    --�p��date_sec1�P 2000/01/01 00:00�����j����
    --�ѼƮt���⦨����
    wrk_date_1 := '0000101';
    wrk_date_2 := substr(date_sec2, 1, 7);
    ystd.bt_date(wrk_date_1, wrk_date_2, wrk_xdays, swt_err);
    wrk_sec2 := abs(wrk_xdays * 24 * 60 * 60);
    --
    --�p�ɼƮt���⦨����
    wrk_sec2 := wrk_sec2 + to_number(substr(date_sec2, 8, 2)) * 60 * 60;
    --
    --�����Ʈt���⦨����
    wrk_sec2 := wrk_sec2 + to_number(substr(date_sec2, 10, 2)) * 60;
    --
    wrk_sec2 := wrk_sec2 + to_number(substr(date_sec2, 12, 2));
    --
    return abs(wrk_sec2 - wrk_sec1);
  end;*/

  /*�P�_§���X 97.08.27*/
  function f_weekday(p_date in varchar2) return varchar2 is
    val1  number;
    val2  number;
    val2x number;
    val3  number;
    val4  number;
    val5  number;
    val6  number;
    val7  number;
    val8  number;
    val9  number;
    val0  number;
  begin
    val1  := to_number(substr(p_date, 6, 2));
    val2  := to_number(substr(p_date, 4, 2));
    val2x := val2;
    val3  := to_number(substr(p_date, 1, 3)) + 1911;
    if (val2 = 1) then
      val2x := 13;
      val3  := val3 - 1;
    end if;
    if (val2 = 2) then
      val2x := 14;
      val3  := val3 - 1;
    end if;
    val4 := trunc(((val2x + 1) * 3) / 5);
    val5 := trunc(val3 / 4);
    val6 := trunc(val3 / 100);
    val7 := trunc(val3 / 400);
    val8 := val1 + (val2x * 2) + val4 + val3 + val5 - val6 + val7 + 2;
    val9 := trunc(val8 / 7);
    val0 := val8 - (val9 * 7);
    if val0 = 0 then
      return('��');
    elsif val0 = 1 then
      return('��');
    elsif val0 = 2 then
      return('�@');
    elsif val0 = 3 then
      return('�G');
    elsif val0 = 4 then
      return('�T');
    elsif val0 = 5 then
      return('�|');
    elsif val0 = 6 then
      return('��');
    else
      return('?');
    end if;
  end f_weekday;

  

  /* rndchar : ���ͶüƦr�����  2009.08.19*/
  function rndchar return varchar2 is
    wrk_rndchar varchar2(1);
  begin
    select decode(trunc(dbms_random.value * 36) + 1,
                  1,
                  '1',
                  2,
                  '2',
                  3,
                  '3',
                  4,
                  '4',
                  5,
                  '5',
                  6,
                  '6',
                  7,
                  '7',
                  8,
                  '8',
                  9,
                  '9',
                  10,
                  '0',
                  11,
                  'A',
                  12,
                  'B',
                  13,
                  'C',
                  14,
                  'D',
                  15,
                  'E',
                  16,
                  'F',
                  17,
                  'G',
                  18,
                  'H',
                  19,
                  'I',
                  20,
                  'J',
                  21,
                  'K',
                  22,
                  'L',
                  23,
                  'M',
                  24,
                  'N',
                  25,
                  'O',
                  26,
                  'P',
                  27,
                  'Q',
                  28,
                  'R',
                  29,
                  'S',
                  30,
                  'T',
                  31,
                  'U',
                  32,
                  'V',
                  33,
                  'W',
                  34,
                  'X',
                  35,
                  'Y',
                  36,
                  'Z',
                  '?')
      into wrk_rndchar
      from dual;
    return wrk_rndchar;
  end rndchar;

  /* IDtoNID : �����Ҧr����NOTEID  2010.05.02*/
  function IDtoNID(p_ID varchar2) return varchar2 is
    --wrk_noteid varchar2(10);
  begin
    --select empid into wrk_noteid from v0nbfc00@temp where idno = p_ID;
    return p_ID;
  end;

  /* skip_holiday : p_date_s�[p_xdays�u�@��  2011.04.01*/
  --p_skip:Y:���L null:�����L
  

  /* f0a:t0nkdg0a�N�X���W�� */
  function f0a(p_dtid in varchar2, p_id in varchar2) return varchar2 is
    wrk_nm t0nkdg0a.nm%type;
    --p_dtid='1' : �]�����O
  begin
    
      select nm
        into wrk_nm
        from t0nkdg0a
       where dtid = p_dtid
         and id = p_id;
      return wrk_nm;
  exception
    when others then
      return null;
  end f0a;

  
  --

  /* f_mpznm:���q�B�Ͳ��t�B�s�{�ϥN�����s�{�ϦW��  101.08.03*/
  function f_mpznm(p_co varchar2, p_pmfct varchar2, p_mpz varchar2)
    return varchar2 is
    wrk_mpznm t0nkpme0.cnm%type;
  begin
    begin
      select cnm
        into wrk_mpznm
        from t0nkpme0
       where co = p_co
         and pmfct = p_pmfct
         and mpzid = p_mpz;
      return wrk_mpznm;
    exception
      when others then
        return '';
    end;
  end f_mpznm;

  /* f_mpsysnm:���q�B�Ͳ��t�B�s�{�ϥN���B�s�{�Ϩt�ΥN���B���s�{�Ϩt�ΦW��  101.08.03*/
  function f_mpsysnm(p_co    varchar2,
                     p_pmfct varchar2,
                     p_mpz   varchar2,
                     p_mpsys varchar2) return varchar2 is
    wrk_mpsysnm t0nkpme1.cnm%type;
  begin
    begin
      select cnm
        into wrk_mpsysnm
        from t0nkpme1
       where co = p_co
         and pmfct = p_pmfct
         and mpzid = p_mpz
         and mpsysid = p_mpsys;
      return wrk_mpsysnm;
    exception
      when others then
        return '';
    end;
  end f_mpsysnm;

  /* get_eql:���]�ư�ǤW�U��  101.08.03*/
  function get_eql(p_opco  varchar2,
                   p_oppld varchar2,
                   p_opdp  varchar2,
                   p_wayid varchar2,
                   p_sqno  varchar2,
                   p_fun   varchar2,
                   p_chkkd varchar2,
                   p_it    varchar2,
                   p_chkit varchar2,
                   p_stdid varchar2,
                   p_type  varchar2) return number is
    --p_type U:�W�� L:�U��
    wrk_cycqty t0nkdgm5.cycqty%type;
    wrk_cycun  t0nkdgm5.cycun%type;
    wrk_eqno   t0nkdgd5_2.eqno%type;
    wrk_pmfct  t0nkdgd5_2.pmfct%type;
    wrk_co     t0nkdgd5_2.co%type;
    wrk_upl    number;
    wrk_ll     number;
  begin

    begin
      select cycqty, cycun
        into wrk_cycqty, wrk_cycun
        from t0nkdgm5
       where opco = p_opco
         and oppld = p_oppld
         and opdp = p_opdp
         and wayid = p_wayid;
    exception
      when others then
        wrk_cycqty := null;
        wrk_cycun  := null;
    end;
    --
    --���]�ƽs���B�]�ƦW��
    begin
      select eqno, PmFct, co
        into wrk_eqno, wrk_pmfct, wrk_co
        from T0NKDGD5_2
       where opco = p_opco
         and OpPld = p_oppld
         and OpDp = p_opdp
         and WayId = p_wayid
         and Sqno = p_sqno
         and It = p_it;
    exception
      when others then
        wrk_eqno  := null;
        wrk_pmfct := null;
        wrk_co    := null;
    end;
    --

    begin
      select upl, ll
        into wrk_upl, wrk_ll
        from t0nkdgd2_3
       where OPCO = p_opco
         and OPPLD = p_oppld
         and OPDP = p_opdp
         and FUN = p_fun
         and CHKKD = p_chkkd
       --  and CYCQTY = wrk_cycqty
       --  and CYCUN = wrk_cycun
         and CO = wrk_co
         and PMFCT = wrk_pmfct
         and EQNO = wrk_eqno
         and CHKIT = p_chkit
         and STDID = p_stdid;
    exception
      when others then
        wrk_upl := null;
        wrk_ll  := null;
    end;

    if p_type = 'U' then
      return wrk_upl;
    elsif p_type = 'L' then
      return wrk_ll;
    end if;
  end get_eql;

 
  

  /* isChar:�t�^��βŸ��r�� 101.11.13*/
  FUNCTION isChar(p_IN IN VARCHAR2) RETURN boolean IS
    WRK_NUM NUMBER(10) := 0;
  BEGIN

    WRK_NUM := instr(translate(upper(p_IN),
                               'ABCDEFGHIJKLMNOPQRSTUVWXYZ+"/\*@!$%&^<>?#',
                               '#########################################'),
                     '#');
    if WRK_NUM > 0 THEN
      --�Y�ǤJ�r��t�^��r���S���r��,�^�� true
      RETURN true;
    ELSE
      RETURN false;
    end IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN false;
  END isChar;

  /* P_APPLY_COMMON:�M�Φ@�q�ʰ�� 101.11.26*/
  
  

 

  

  /* f_eqkd:���]�����O 102.03.05 */
  function f_eqkd(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2 is
    wrk_eqkd varchar2(10);
  begin
    select eqkd
      into wrk_eqkd
      from t0nkpme3
     where co = p_co
       and pmfct = p_pmfct
       and eqno = p_eqno;
    return wrk_eqkd;
  exception
    when others then
      return null;
  end f_eqkd;

  /* f_eqty:���]�ƫ��� 102.03.05 */
  function f_eqty(p_co varchar2, p_pmfct varchar2, p_eqno varchar2)
    return varchar2 is
    wrk_eqty varchar2(10);
  begin
    select eqty
      into wrk_eqty
      from t0nkpme3
     where co = p_co
       and pmfct = p_pmfct
       and eqno = p_eqno;
    return wrk_eqty;
  exception
    when others then
      return null;
  end f_eqty;

  

  /* f_mylengthb:���r��� 102.05.24 */
  function f_mylengthb(p_str varchar2) return number is
  begin
    return lengthb(p_str);
  end f_mylengthb;

  


  /* f_eqpmsect:���]�ƥͲ��� 103.04.22 */
  function f_eqpmsect(p_co varchar2,p_pmfct varchar2,p_eqno varchar2) return varchar2 is
    wrk_pmsect t0nkpme3.pmsect%type;
  begin
    select nvl(pmsect,pmfct)
      into wrk_pmsect
      from t0nkpme3
     where co=p_co
       and pmfct=p_pmfct
       and eqno=p_eqno;
    return wrk_pmsect;
  exception
    when others then
      return p_pmfct;
  end f_eqpmsect;


  
  --�ˬd�g��  add by T007(2014.11.28)
  procedure p_chk_cycqty(i_cycqty number, i_cycun varchar2, o_msg out varchar2) is
  begin
    if i_cycun not in ('H','D','W','M') then
       o_msg := '�g���N���u���JH,D,W,M';
       return;
    end if;
    --�p��
    if    i_cycun='H' then
          if mod(i_cycqty,24)=0 then
             o_msg := '�g��'||i_cycqty||i_cycun||','||'���קאּ'||to_char(i_cycqty/24)||'D';
             return;
          else
             o_msg := '';
             return;
          end if;
    --��
    elsif i_cycun='D' then
          if mod(i_cycqty,7)=0 then
             o_msg := '�g��'||i_cycqty||i_cycun||','||'���קאּ'||to_char(i_cycqty/7)||'W';
             return;
          else
             o_msg := '';
             return;
          end if;
    --�g
    elsif i_cycun='W' then
          if mod(i_cycqty,4)=0 then
             o_msg := '�g��'||i_cycqty||i_cycun||','||'���קאּ'||to_char(i_cycqty/4)||'M';
             return;
          else
             o_msg := '';
             return;
          end if;
    else
          o_msg := '';
          return;
    end if;
  end;
 

  --���q�B�t�B�B�����B���u�N�����g���ƶq ���*/  --add by T058(2015.06.09)
  function get_cycqty(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 is
    wk_cycqty   VARCHAR2(3);
    --
    cursor c_dg05 is
           select to_char(cycqty)
             from t0nkdgm5
            where opco=in_co and
                  oppld=in_pld and
                  opdp=in_dp and
                  wayid=in_wayid 
            order by nvl(paubegdat,'9999999') desc,nvl(paupaudat,'9999999') desc;
  begin
    open c_dg05;
    fetch c_dg05 into wk_cycqty;
    if c_dg05%notfound then
       wk_cycqty  := '';
    end if;
    close c_dg05;
    --
    return wk_cycqty ;
  exception
    when others then
         return wk_cycqty ;
  end get_cycqty;
    --���q�B�t�B�B�����B���u�N�����g�����*/  --add by T058(2015.06.09)
  function get_cycun(in_co in varchar2, in_pld in varchar2, in_dp in varchar2, in_wayid in varchar2) return varchar2 is
    wk_cycun   VARCHAR2(2);
    --
    cursor c_dg05 is
           select cycun
             from t0nkdgm5
            where opco=in_co and
                  oppld=in_pld and
                  opdp=in_dp and
                  wayid=in_wayid 
            order by nvl(paubegdat,'9999999') desc,nvl(paupaudat,'9999999') desc;
  begin
    open c_dg05;
    fetch c_dg05 into wk_cycun;
    if c_dg05%notfound then
       wk_cycun  := '';
    end if;
    close c_dg05;
    --
    return wk_cycun ;
  exception
    when others then
         return wk_cycun ;
  end get_cycun;
  --------------------------------
    --���q�B�t�B�B�]�ƨ��]�ƦW��*/  --add by T058(2015.06.15)
  function get_egnm(in_co in varchar2, in_pld in varchar2,in_egno in varchar2) return varchar2 is
    wk_egnm   VARCHAR2(40);
    --
    cursor c_me3 is
           SELECT substrb(eqnm,1,40)
             from T0NKPME3
            where co   = in_co
              AND pmfct  = in_pld
              AND eqno   = in_egno;
  begin
    open c_me3;
      fetch c_me3 into wk_egnm;
        if c_me3%notfound then
           wk_egnm  := '';
        end if;
    close c_me3;
    --
    return wk_egnm ;
  exception
    when others then
         return wk_egnm ;
  end get_egnm;
  --------------------------------
end p0nkdg01;
/
