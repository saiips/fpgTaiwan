package com.fpg.view.bean;

import java.io.Serializable;

import java.util.Map;

import oracle.binding.OperationBinding;

public class PageFlowManagedBean extends BaseBean implements Serializable {
    @SuppressWarnings("compatibility")
    private static final long serialVersionUID = 1L;

    public PageFlowManagedBean() {
        super();
    }
    
    public void getFunName() {
        OperationBinding method = null;
        Map paramsMap1 = null;
        method = this.getOperationBinding("getFunName");
        paramsMap1 = method.getParamsMap();
        paramsMap1.put("isNew", Boolean.TRUE);
        method.execute();
    }
    
    public void getCTLPTName() {
        OperationBinding method = null;
        Map paramsMap1 = null;
        method = this.getOperationBinding("getCTLPTName");
        paramsMap1 = method.getParamsMap();
        paramsMap1.put("isNew", Boolean.TRUE);
        method.execute();
    }    
    
    public void getDisplayNames() {
        OperationBinding method = null;
        Map paramsMap1 = null;
        Map paramsMap2 = null;
        Map paramsMap3 = null;
        Map paramsMap4 = null;
        Map paramsMap5 = null;
        
        // this.getOperationBinding("getMpzName").execute();
        method = this.getOperationBinding("getMpzName");
        paramsMap1 = method.getParamsMap();
        paramsMap1.put("isNew", Boolean.TRUE);
        method.execute();
        
        // this.getOperationBinding("getMpsysName").execute();
        method = this.getOperationBinding("getMpsysName");
        paramsMap2 = method.getParamsMap();
        paramsMap2.put("isNew", Boolean.TRUE);
        method.execute();
        
        // this.getOperationBinding("getChkkd1Name").execute();
        method = this.getOperationBinding("getChkkd1Name");
        paramsMap3 = method.getParamsMap();
        paramsMap3.put("isNew", Boolean.TRUE);
        method.execute();

        // this.getOperationBinding("getChkkd2Name").execute();
        method = this.getOperationBinding("getChkkd2Name");
        paramsMap4 = method.getParamsMap();
        paramsMap4.put("isNew", Boolean.TRUE);
        method.execute();

        // this.getOperationBinding("getChkkd3Name").execute();
        method = this.getOperationBinding("getChkkd3Name");
        paramsMap5 = method.getParamsMap();
        paramsMap5.put("isNew", Boolean.TRUE);
        method.execute();
    }
}
