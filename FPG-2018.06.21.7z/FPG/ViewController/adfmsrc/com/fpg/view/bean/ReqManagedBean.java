package com.fpg.view.bean;

import com.fpg.model.am.AppModuleAMImpl;
import com.fpg.model.am.common.AppModuleAM;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;

import java.math.BigDecimal;

import java.util.Date;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;

import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.component.rich.RichDialog;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

import org.apache.myfaces.trinidad.event.AttributeChangeEvent;

public class ReqManagedBean extends BaseBean implements Serializable {
    @SuppressWarnings("compatibility")
    private static final long serialVersionUID = 1L;

    public ReqManagedBean() {
        super();
    }

    /* get the chinese name of mpz */
    public void onMPZChange(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getMpzName");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputMpz", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* get the chinese name of mpsys */
    public void onMPSYSChange(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getMpsysName");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputMpz", "");
        paramsMap.put("inputMpsys", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* get the chinese name of chkkd1 */
    public void onCHKKD1Change(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getChkkd1Name");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputChkkd", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* get the chinese name of chkkd2 */
    public void onCHKKD2Change(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getChkkd2Name");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputChkkd", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* get the chinese name of chkkd3 */
    public void onCHKKD3Change(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getChkkd3Name");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputChkkd", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* get the cinese name of ctlptid */
    public void onCTLPTIDChange(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getCTLPTName");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputCtlptid", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* get the chinese name of fun */
    public void onFUNChange(ValueChangeEvent valueChangeEvent) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("getFunName");
        Map paramsMap = method.getParamsMap();
        paramsMap.put("inputFun", (String) valueChangeEvent.getNewValue());
        paramsMap.put("isNew", Boolean.FALSE);
        method.execute();
    }

    /* delete action of deleteT0NKDGM5 */
    private String deleteT0NKDGM5() {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("Delete");
        Object result = method.execute();
        if (!method.getErrors().isEmpty()) {
            return null;
        }
        return null;
    }

    /* delete action of deleteT0NKDGD5_1 */
    private String deleteT0NKDGD5_1() {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("Delete1");
        Object result = method.execute();
        if (!method.getErrors().isEmpty()) {
            return null;
        }
        return null;
    }

    /* delete action of deleteT0NKDGD5_2 */
    private String deleteT0NKDGD5_2() {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("Delete2");
        Object result = method.execute();
        if (!method.getErrors().isEmpty()) {
            return null;
        }
        return null;
    }

    /* commit action */
    private String commitT0NKDGM5() {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = bc.getOperationBinding("Commit");
        Object result = method.execute();
        if (!method.getErrors().isEmpty()) {
            return null;
        }
        return null;
    }




    public void dT0NKDGM5_dialogListener(DialogEvent dialogEvent) {
        if (dialogEvent.getOutcome().equals(dialogEvent.getOutcome().yes)) {
            deleteT0NKDGM5();
            commitT0NKDGM5();
        }
    }

    public void dT0NKDGD5_1_dialogListener(DialogEvent dialogEvent) {
        if (dialogEvent.getOutcome().equals(dialogEvent.getOutcome().yes)) {
            deleteT0NKDGD5_1();
            commitT0NKDGM5();
        }
    }

    public void dT0NKDGD5_2_dialogListener(DialogEvent dialogEvent) {
        if (dialogEvent.getOutcome().equals(dialogEvent.getOutcome().yes)) {
            deleteT0NKDGD5_2();
            commitT0NKDGM5();
        }
    }

    public void csvExport(FacesContext facesContext, OutputStream outputStream) throws IOException {
        DCBindingContainer dc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding method = dc.getOperationBinding("getCsvContent");
        String content = (String) method.execute();
        outputStream.write(content.getBytes());
        outputStream.flush();
    }
}
