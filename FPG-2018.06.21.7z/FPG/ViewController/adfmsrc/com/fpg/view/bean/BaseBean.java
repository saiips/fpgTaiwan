package com.fpg.view.bean;

import java.io.Serializable;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;

import oracle.binding.OperationBinding;

public abstract class BaseBean implements Serializable {
    @SuppressWarnings("compatibility")
    private static final long serialVersionUID = 1L;

    public BaseBean() {
        super();
    }
    
    protected OperationBinding getOperationBinding(String operationName) {
        DCBindingContainer bc = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        return bc.getOperationBinding(operationName);
    }
}
